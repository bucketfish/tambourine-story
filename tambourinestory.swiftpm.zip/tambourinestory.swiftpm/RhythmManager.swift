//
//  RhythmHandler.swift
//  colorsong
//
//  Created by Tongyu Jiang on 3/2/24.
//

import Foundation
import CoreMotion
import AVFoundation


class RhythmManager: ObservableObject {
    static let shared = RhythmManager()
    
    @Published var isCheckingShakes: Bool = false
    
    let soundPlayer = CustomSoundPlayer.shared
//    lazy var narrative = { return NarrativeManager.shared }()
    
    var motionManager = CMMotionManager()
    let queue = OperationQueue()
    
    // music defaults
    let timePerBeat = 0.25 // in seconds
    let beatsPerBar = 8
    let timePerBar = 2.0
    
    let beatThreshold = 0.3 // make this smaller
    
    // like everything
    var all_beatSequences: [[[Double]]] = [
        [ // music 1 intro
            [0, 4],
            [0, 4],
            [0, 4],
            [0, 4],
        ],
        [ // music 2: personal picking up speed!
            [0, 2, 4, 6],
            [0, 2, 4],
            [0, 2, 4, 6, 7],
            [0, 2, 4, 5, 6],
            
            [0, 2, 4, 6],
            [0, 2, 4],
            [0, 2, 4, 6, 7],
            [0, 2, 4, 5, 6],
//
//            [2, 5, 6, 7],
//            [2, 5, 6, 7],
//            [2, 5, 6, 7],
//            [0, 1, 3, 4, 5, 6, 7],
        ],
        [ // music 3: final song!!! RAHHHH
            [2, 6],
            [2, 5, 6],
            [2, 6],
            [2, 5, 6, 7],
            
            [2, 6],
            [2, 5, 6],
            [2, 5, 6, 7],
            [1, 3, 5, 6],
            
            [2, 5, 6],
            [2, 5, 6],
            [1, 3, 5, 6],
            [0, 1, 3, 5, 6],
            
            [2, 5, 6],
            [2, 3, 5, 6],
            [0, 1, 3, 5, 6],
            [0, 1, 3, 4, 5, 6, 7]
        ]
    ]
    
    // current one to use/check
    var beatSequences: [[Double]] = [
        [2, 6],
        [2, 5, 6],
        [2, 5, 6, 7],
        [2, 5, 6, 7],
        [2, 6],
        [2, 5, 6],
        [2, 5, 6, 7],
        [2, 5, 6, 7],
        
    ]
    
    // all the musics!
    let musics = ["music1", "music2", "music3"]
    
    var hitsOfCurrentBar: [Bool] = [] //
    
    // music published
    @Published var currentBarNumber: Int = 0
    @Published var currentNoteNumberOfBar: Int? = 0 // if null, = move on to next bar
    @Published var currentBeatTime: Double = 0.0
    
    // adjusted to ignore threshold
    @Published var realCurrentBarNumber: Int = 0
    @Published var realCurrentNoteNumberOfBar: Int = 0
    @Published var realCurrentBeatTime: Double = 0.0
    
    // oh god i need to store next beat time somewhere.
    @Published var nextBarNumber: Int = 0
    @Published var nextBeatNumber: Int = 0 // never null
    @Published var nextBeatTime: Double = 0.0
    
    
    @Published var isSounding: Bool = false
    @Published var currentNoteIsCorrect: Bool = true
    @Published var prevNoteMissed: Bool = false
    
    @Published var timer: Timer?
    @Published var currentTime: Double = 0
    
    
    // motion defaults
    let motionAccelThreshold: Double = 2.2
    let soundCooldown: Double = 0.15
    
    // tambouring internal
    @Published var soundCooldownTimer: Timer?
    @Published var tambourinePlayer: AVAudioPlayer
    
    
    // motion published
    @Published var motionAccel: Double = 0
    @Published var motionPitch: Double = 0
    @Published var motionRoll: Double = 0
    @Published var motionYaw: Double = 0
    
    // jumping published
    @Published var jumpFrame: Int = 0
    @Published var jumpOffset: Double = 0
    
    // visibility
    @Published var usingTambourine = false
    
    // for calculating passing vs failing
    @Published var tambourineHits: Int = 0
    @Published var tambourineWrongs: Int = 0
    @Published var tambourineMisses: Int = 0
    @Published var percentageHit: Double = 0
    
    @Published var isLooping: Bool = false
    @Published var passThreshold: Double = 0.7 // hit 80% of notes to pass
    
    
    var musicNeedsUpdate: Bool = false
    var musicUpdatedNum: Int = 0
    var musicUpdatedLoop: Bool = false
    
    init() {
        let tambourineURL = Bundle.main.url(forResource: "tambourine", withExtension: "mp3")
        tambourinePlayer = try! AVAudioPlayer(contentsOf: tambourineURL!)
        
        init_manageMotion()
    }
    
    
    func updateMusic(musicNum: Int, loop: Bool = true) {
        musicNeedsUpdate = true
        musicUpdatedNum = musicNum
        musicUpdatedLoop = loop
        // arghhghg
    }
    
    
    func init_manageMotion() {
        
        self.motionManager.startDeviceMotionUpdates(to: self.queue) { (data: CMDeviceMotion?, error: Error?) in
            guard let data = data else {
                print("Error: \(error!)")
                return
            }
            
            let accel: CMAcceleration = data.userAcceleration
            
            
            DispatchQueue.main.async {
                
                let attitude: CMAttitude = data.attitude
                self.motionPitch = attitude.pitch
                self.motionYaw = attitude.yaw
                self.motionRoll = attitude.roll
                
                self.motionAccel = accel.x * accel.x + accel.y * accel.y + accel.z * accel.z
                
                if (self.motionAccel >= self.motionAccelThreshold && !self.isSounding && self.usingTambourine && NarrativeManager.shared.showGame) {
                    //                    play(sound: "tambourine3.mp3")
                    
                    self.tambourinePlayer.currentTime = 0
                    self.tambourinePlayer.play()
                    
                    if self.isCheckingShakes {
                        self.checkNoteAccuracy()
                    }
                    
                    self.isSounding = true
                    self.soundCooldownTimer = Timer.scheduledTimer(withTimeInterval: self.soundCooldown, repeats: false) {_ in
                        self.isSounding = false
                    }
                }
            }
        }
    }
    
    
    
    func start_music(_ musicNum: Int, loop: Bool = false) {

        self.isLooping = loop
        usingTambourine = true // make sure tambourine makes sounds!
        
        // start playing the music
        soundPlayer.play(self.musics[musicNum])
        
        if loop {
            soundPlayer.player?.numberOfLoops = -1
        }
        else {
            soundPlayer.player?.numberOfLoops = 0
        }
        
        // update relevant stuff
        self.beatSequences = self.all_beatSequences[musicNum]
        if loop {
            self.beatSequences.append(self.beatSequences[0])
        }
        
        
        // start timing!
        self.timer?.invalidate()
        init_musicTimer()
    }
    
    
    
    // MARK: music timer main func
    func init_musicTimer() {
        self.currentBarNumber = 0
        self.currentNoteNumberOfBar = 0 // if null, = move on to next bar
        self.currentBeatTime = 0.0
        
        self.realCurrentBarNumber = 0
        self.realCurrentNoteNumberOfBar = 0
        self.realCurrentBeatTime = 0.0
        
        self.nextBarNumber = 0
        self.nextBeatNumber = 0 // never null
        self.nextBeatTime = 0.0
        self.currentTime = 0.0
        
        self.hitsOfCurrentBar = []
        
        
        
        self.timer = Timer.scheduledTimer(withTimeInterval: 0.005, repeats: true) { _ in
            // restart if it looped!
            if let soundTime = self.soundPlayer.player?.currentTime {
                if soundTime < self.currentTime && self.isLooping {
                    self.doLoopStuff()

                    self.timer?.invalidate()
                    self.init_musicTimer()
                    return
                }
            }

            // continue as normal
            self.currentTime = self.soundPlayer.player?.currentTime ?? 0.0
//
            if let splayer = self.soundPlayer.player?.isPlaying {
                if !splayer {
                    self.doEndStuff()
                    self.timer?.invalidate()
                    return
                }
            }
            else {
                self.doEndStuff()
                self.timer?.invalidate()
                return
            }

            
            // increase bar number if moved past current bar
            if (self.currentTime >= (Double(self.currentBarNumber) + 1) * self.timePerBar) {
                self.currentBarNumber += 1
                self.currentNoteNumberOfBar = 0
                
                // stop the thing if finished
                if (self.currentBarNumber >= self.beatSequences.count) {
                    self.currentBarNumber = self.beatSequences.count - 1
                    
                    if self.isLooping {
                        self.doLoopStuff()
                        self.timer?.invalidate()
                        self.init_musicTimer()
                        
                        return
                    }
                    else {
                        self.doEndStuff()
                        self.timer?.invalidate()
                        return
                    }
                    
                }
            }
            
            
            
                        
            // increase beat number if prev beat was missed
            if let currentNote = self.currentNoteNumberOfBar{
                
                self.currentBeatTime = (Double(self.currentBarNumber) * self.timePerBar) + (self.beatSequences[self.currentBarNumber][currentNote] * self.timePerBeat)
                
                // if missed prev beat
                if (self.currentTime > self.currentBeatTime + self.beatThreshold) && self.isCheckingShakes{
                    self.currentNoteIsCorrect = false
                    self.prevNoteMissed = true
                    print("missed")

                    
                    self.hitsOfCurrentBar.append(false)
                    
                    self.tambourineMisses += 1
                    
                    
                    if (currentNote + 1 >= self.beatSequences[self.currentBarNumber].count) {
                        
                        if self.currentBarNumber + 1 < self.beatSequences.count {
                            self.currentNoteNumberOfBar = 0
                            
                            self.currentBarNumber += 1
                        }
                        else {
                            self.currentNoteNumberOfBar = nil
                            
//                            self.currentBarNumber += 1
                        }
                    }
                    else {
                        self.currentNoteNumberOfBar = currentNote +  1
                    }
                }
                else {

                }
            }
            
            // update real note pos
            self.updateRealNumbers()
            
            
            // calculate percentage hit
            if self.isCheckingShakes && (self.tambourineMisses + self.tambourineHits > 0) {
                self.percentageHit = Double(Double(self.tambourineHits) / Double(self.tambourineMisses + self.tambourineHits))
            }
            
            
            
            // position the jumping girl
            self.positionJumping()
            
                        
        }
    }
    
    func doEndStuff () {
        NarrativeManager.shared.advance()
    }

    func doLoopStuff() {
        
        if self.isCheckingShakes && (self.tambourineHits + self.tambourineMisses) >= 8 {
            if self.percentageHit >= passThreshold {
                NarrativeManager.shared.advance(skipLine: true)
            }
            else {
                NarrativeManager.shared.advance(stayAtLine: true)
            }
        }
        
        
        self.tambourineHits = 0
        self.tambourineWrongs = 0
        self.tambourineMisses = 0
        self.percentageHit = 0
        
        
        
        if musicNeedsUpdate {
            musicNeedsUpdate = false
            start_music(musicUpdatedNum, loop: musicUpdatedLoop)
        }
    }
    
    
    func updateNextBeat() {
        
        if (realCurrentNoteNumberOfBar + 1 >= self.beatSequences[self.realCurrentBarNumber].count) {
            self.nextBarNumber = realCurrentBarNumber + 1
            self.nextBeatNumber = 0
        }
        else {
            self.nextBarNumber = realCurrentBarNumber
            self.nextBeatNumber = realCurrentNoteNumberOfBar + 1
        }
        
        if self.nextBarNumber >= self.beatSequences.count {
            self.nextBarNumber -= 1
            self.nextBeatTime = soundPlayer.player?.duration ?? 0.0
        }
        else {
            self.nextBeatTime = (Double(self.nextBarNumber) * self.timePerBar) + (self.beatSequences[self.nextBarNumber][nextBeatNumber] * self.timePerBeat)

        }
        
    }
    
    
    func updateRealNumbers() {
        let new = Int(floor(Double(self.currentTime) / Double(self.timePerBar)))
        
        if new != self.realCurrentBarNumber {
                if self.hitsOfCurrentBar.count > 1 {
                    self.hitsOfCurrentBar = []
                }
        }
        
        self.realCurrentBarNumber = new
        
        let currentBeatTime: Double = self.currentTime - self.timePerBar * Double(self.realCurrentBarNumber)
        
        let currentBeatNumber = Int(floor(currentBeatTime / Double(timePerBeat)))
        
        self.realCurrentNoteNumberOfBar = self.beatSequences[self.realCurrentBarNumber].lastIndex(where: {Int($0) <= currentBeatNumber}) ?? 0
        
        
        
        self.realCurrentBeatTime = (Double(self.realCurrentBarNumber) * self.timePerBar) + (self.beatSequences[self.realCurrentBarNumber][self.realCurrentNoteNumberOfBar] * self.timePerBeat)

        
//        if realCurrentNoteNumberOfBar == 0 {
//            if self.hitsOfCurrentBar.count > 1 {
//                self.hitsOfCurrentBar = []
//            }
//        }
        
        self.updateNextBeat()
    }
        
//        
//        self.realCurrentBeatTime = (Double(self.realCurrentBarNumber) * self.timePerBar) + (self.beatSequences[self.realCurrentBarNumber][self.realCurrentNoteNumberOfBar] * self.timePerBeat)
//
//        
//        self.updateNextBeat()
//
//        
//        if (self.currentTime >= self.nextBeatTime) {
//            
//            if (self.realCurrentNoteNumberOfBar + 1 >= self.beatSequences[self.realCurrentBarNumber].count) {
//                self.realCurrentNoteNumberOfBar = 0
//                self.realCurrentBarNumber += 1
//                
//                if self.hitsOfCurrentBar.count > 1 {
//                    self.hitsOfCurrentBar = []
//                }
//                
//            }
//            else {
//                self.realCurrentNoteNumberOfBar += 1
//            }
            
//            if /*self.realCurrentBarNumber == self.currentBarNumber &&*/ self.realCurrentBeatTime == self.currentBeatTime {
//                self.currentNoteIsCorrect = false
//            } // ???? so scuffed at this int
            
//        }
//    }
    
    func positionJumping() {
        // positioning:
        // O - O - O - O -(center)- O - O - O - O
        // total distance should go beyond last ball — total distance = (80 + 50) * 8
        
        var tempRealCurrentBeatTime = self.realCurrentBeatTime

        if self.currentTime < self.realCurrentBeatTime {
            tempRealCurrentBeatTime = Double(self.realCurrentBarNumber) * self.timePerBar - self.timePerBeat
        }
        
        
        let timePassed = self.currentTime - tempRealCurrentBeatTime
        var timeTotal = self.nextBeatTime - tempRealCurrentBeatTime
        
        if self.currentTime < self.realCurrentBeatTime {
            timeTotal = self.currentBeatTime - tempRealCurrentBeatTime
        }
        
        if timeTotal.isZero {
            timeTotal = Double(self.realCurrentBarNumber) * self.timePerBar
        }

        if !timeTotal.isZero {
            let newNum = Int(floor(timePassed / timeTotal * 6))

            if (newNum < 6 && newNum >= 0) {
                self.jumpFrame = newNum
            }
        }
        
        var timePassedOfBar = (self.currentTime - Double(self.realCurrentBarNumber) * self.timePerBar)
        
        // if it goes out of frame into next bar
        if self.currentTime > Double(self.realCurrentBarNumber + 1) * self.timePerBar {
            timePassedOfBar = (self.currentTime - Double(self.realCurrentBarNumber + 1) * self.timePerBar)
        }
        
        self.jumpOffset = timePassedOfBar / (self.timePerBar) * 1040
    }
    
    
    // MARK: check note accuracy
    func checkNoteAccuracy() {
        if let currentNote = self.currentNoteNumberOfBar { // if no next beat, don't do anything lol
            self.currentBeatTime = (Double(self.currentBarNumber) * self.timePerBar) + (self.beatSequences[self.currentBarNumber][currentNote] * self.timePerBeat)
            
            // note is in current beat!
            if (self.currentTime > self.currentBeatTime - beatThreshold && self.currentTime < self.currentBeatTime + self.beatThreshold) {
                self.currentNoteIsCorrect = true
                
                _ = Timer.scheduledTimer(withTimeInterval: self.timePerBeat / 1.5, repeats: false) { _ in
                    self.currentNoteIsCorrect = false
                }
                
                
                
                self.prevNoteMissed = false
                
//                if self.currentNoteNumberOfBar == 0 {
//                    self.hitsOfCurrentBar = []
//                }
                
                print("hit")
                self.hitsOfCurrentBar.append(true)
                if self.currentNoteNumberOfBar == 0 && self.realCurrentNoteNumberOfBar != 0 {
                    _ = Timer.scheduledTimer(withTimeInterval: self.beatThreshold, repeats: false) { _ in
                        self.hitsOfCurrentBar.append(true)
//                        self.currentNoteIsCorrect = false
                    }
                }
                
                tambourineHits += 1
                
                // FIX THIS PART! if you inc the note number beyond current bar — coordinate & inc bar
                if (currentNote + 1 >= self.beatSequences[self.currentBarNumber].count) {
//                    self.currentNoteNumberOfBar = nil
                    if self.currentBarNumber + 1 < self.beatSequences.count {
                        self.currentNoteNumberOfBar = 0
                        
                        self.currentBarNumber += 1
                    }
                    else {
                        self.currentNoteNumberOfBar = nil
                        
//                            self.currentBarNumber += 1
                    }
                }
                else {
                    self.currentNoteNumberOfBar = currentNote + 1
                }

            }
            
            // note is NOT in current beat! die
            else {
                self.currentNoteIsCorrect = false
                print("hit wrong")
                
                self.tambourineWrongs += 1
            }
        }
        
        self.updateNextBeat()
        
    }
    
    
    
}
