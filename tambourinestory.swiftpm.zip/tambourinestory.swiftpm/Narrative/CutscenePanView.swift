//
//  SwiftUIView.swift
//  
//
//  Created by Tongyu Jiang on 15/2/24.
//

import SwiftUI



struct CutscenePanView: View {
    @EnvironmentObject var rhythm: RhythmManager
    @EnvironmentObject var narrative: NarrativeManager

    
    @State var tambourineOffset = 0
    @State var direOffset = 0
    @State var dialogueLoading = false
    @State var dialogueOnFast = false
    
    
//    @State var colorOpacity: Double = 1
    
    var body: some View {
        ZStack {
            GeometryReader { proxy in
                ZStack {
                    Image(narrative.backgroundImage)
                        .resizable()
                        .scaledToFill()

                    Image("tambourine_in_room")
                        .resizable()
                        .scaledToFill()
                        .rotationEffect(.degrees(Double(narrative.tambourineShake)), anchor: UnitPoint(x: 0.4, y: 0.68))
                        .offset(y: CGFloat(narrative.tambourineOffset))
                        .animation(.spring(), value: narrative.tambourineOffset)
                        .animation(.spring(), value: narrative.tambourineShake)

                    
                    Image("dire")
                        .resizable()
                        .scaledToFill()
                        .offset(y: CGFloat(narrative.direOffset))
                        .animation(.spring(), value: narrative.direOffset)
                }
                    .frame(height: proxy.size.height * 1.15)
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .offset(
                        x: clamp(rhythm.motionPitch * 60 + rhythm.motionYaw * 60, -150, 150),
                        y: clamp(-50 - rhythm.motionRoll * 75, -25, 25)
                        )
            }
            
            Color(.black)
                .opacity(narrative.shadowOpacity)
                .animation(.spring(), value: narrative.shadowOpacity)
                .ignoresSafeArea(.all)
            
            
//            if narrative.showGame {
            TambourineView(showStuff: $narrative.showGame)
                .environmentObject(rhythm)
//            }
            
            DialogueView(imageName: $narrative.dialogueCharacterImage, dialogueLine: $narrative.dialogueLine, speakingIsLeft: $narrative.isDialogueAtLeft, dialogueLoading: $dialogueLoading, dialogueOnFast: $dialogueOnFast)
            
            
            
            Color(red: 0.6, green: 0.74, blue: 1)
                .opacity(narrative.gameColorOpacity)
                .animation(.spring(blendDuration: 0.4), value: narrative.gameColorOpacity)
                .ignoresSafeArea(.all)
            
        }
        .onTapGesture(count: 1) {
            if narrative.advanceLocked {
                // do nothing; it's locked!
            }
            else if dialogueLoading {
                dialogueOnFast = true
            } else {
                narrative.advance()
            }
        }
        .onAppear {
            narrative.gameColorOpacity = 0
            _ = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: false) { _ in
                narrative.advanceLocked = false
            }
        }
    }
    
    func clamp(_ x: Double, _ from: Double, _ to: Double) -> Double {
        if (x < from) {
            return from
        }
        else if (x > to) {
            return to
        }
        else { return x }
    }
    
}

#Preview {
    CutscenePanView()
}
