//
//  File.swift
//  
//
//  Created by Tongyu Jiang on 17/2/24.
//

import Foundation

class NarrativeManager: ObservableObject {
    static let shared = NarrativeManager()
    
    var rhythm = RhythmManager.shared
    @Published var backgroundImage: String = "room1"
    
    @Published var isDialogueAtLeft: Bool = true
    @Published var dialogueCharacterImage: String = "girl2"
    @Published var dialogueLine: String = "(Tap to continue)"
    
    
    @Published var actionLineIndex: Int = 0
    
    @Published var tambourineOffset: Int = 0
    @Published var tambourineShake: Int = 0
    @Published var direOffset:Int = 0
    
    @Published var showGame: Bool = false
    
    @Published var advanceLocked: Bool = true
    
    @Published var shadowOpacity: Double = 0.0
    
    @Published var gameState: GameState = .start
    @Published var gameColorOpacity: Double = 1.0
    
    
    var onAutoAdvance = false
    var timer: Timer?
    
    var rollbackNext: Bool = false
    
    
    let actions: [Action] = [
        DialogueLine(line: "(Tap to continue)", person: .mc, expression: 2), // must start here cuz nothing happens.

        DialogueLine(line: "Music...", person: .mc, expression: 2),
        DialogueLine(line: "Hey! What are you writing?", person: .brother, expression: 2),
        DialogueLine(line: "Ahh!", person: .mc, expression: 4),
        DialogueLine(line: "Nothing, haha.", person: .mc, expression: 4),
        DialogueLine(line: "If you say so...", person: .brother, expression: 2),
        DialogueLine(line: "...", person: .mc, expression: 4),
        DialogueLine(line: "Actually, I've been thinking...", person: .mc, expression: 4),
        DialogueLine(line: "I really want to join your band!", person: .mc, expression: 1),
        DialogueLine(line: "You? In the band?", person: .brother, expression: 2),
        DialogueLine(line: "Don't you have to be, like, older, or something?", person: .brother, expression: 2),

        OtherAction(autoAdvance: true, action: "lower_dire"),
        DialogueLine(line: "But I love music!", person: .mc, expression: 1),
        DialogueLine(line: "And I really want to learn an instrument!!!", person: .mc, expression: 3),
        DialogueLine(line: "Hey, it's nothing personal!", person: .brother, expression: 3),
        DialogueLine(line: "It's just...", person: .brother, expression: 3),
        DialogueLine(line: "You're not really what we're looking for right now.", person: .brother, expression: 3),
        DialogueLine(line: "Oh...", person: .mc, expression: 3),
        DialogueLine(line: "Keep practising, and you'll get there one day, okay?", person: .brother, expression: 1),
        DialogueLine(line: "We've got rehearsal now, so don't disturb us.", person: .brother, expression: 1),
        
        ChangeBackground(newBackground: "room2"),
        ChangeBackground(newBackground: "room3"),
        DialogueLine(line: "Maybe he's right... why am I even trying?", person: .mc, expression: 3),
        OtherAction(autoAdvance: true, action: "start_rehearsal_music"),
        DialogueLine(line: "Man, they sound so good...", person: .mc, expression: 4),
        OtherAction(autoAdvance: false, action: "highlight_tambourine"),
        DialogueLine(line: "Wait, that's my brother's old tambourine!", person: .mc, expression: 4),
        DialogueLine(line: "Huh...", person: .mc, expression: 1),
        DialogueLine(line: "I wonder...?", person: .mc, expression: 1),

        OtherAction(autoAdvance: true, action: "show_tambourine"),
        DialogueLine(line: "Okay... I just have to shake the tambourine when I reach a note!", person: .mc, expression: 2),
        
        OtherAction(autoAdvance: false, action: "start_tambourine"),
        DialogueLine(autoAdvance: false, line: "", person: .mc, expression: 2),
        
        // placeholder line to stay at if needed lol.
        DialogueLine(autoAdvance: false, line: "Hm, I need to hit more notes...  (Shake your iPad to play the tambourine.)", person: .mc, expression: 4),
        
        // here transition into music2
        OtherAction(autoAdvance: false, action: "stage_2_dialogue"),
        DialogueLine(line: "That was fun!", person: .mc, expression: 2),
        DialogueLine(line: "What if I try something more...", person: .mc, expression: 1),
        DialogueLine(line: "Like, maybe having more notes!", person: .mc, expression: 2),

        OtherAction(autoAdvance: false, action: "start_tambourine2"),
        DialogueLine(autoAdvance: false, line: "", person: .mc, expression: 2),

        OtherAction(autoAdvance: false, action: "stage_3_dialogue"),
        ChangeBackground(newBackground: "room2"),
        ChangeBackground(newBackground: "room1"),
        DialogueLine(line: "Whoa, was that you?", person: .brother, expression: 2),
        DialogueLine(line: "Oh hi! Yeah!", person: .mc, expression: 2),
        DialogueLine(line: "That was actually really cool!", person: .brother, expression: 1),
        DialogueLine(line: "... Do you want to try with us?", person: .brother, expression: 1),
        DialogueLine(line: "Really? You mean it?", person: .mc, expression: 1),
        DialogueLine(line: "Let's give it a shot!", person: .brother, expression: 1),
        ChangeBackground(newBackground: "broom"),
        
        DialogueLine(line: "I'll try my best then!", person: .mc, expression: 2),
        OtherAction(autoAdvance: false, action: "start_tambourine3"),
        DialogueLine(autoAdvance: false, line: "", person: .mc, expression: 2),
        
        OtherAction(autoAdvance: false, action: "final_dialogue"),
        DialogueLine(line: "Whoa.", person: .mc, expression: 1),
        DialogueLine(line: "Whoa yourself!", person: .brother, expression: 1),
        DialogueLine(line: "That was not half bad!", person: .brother, expression: 1),
        DialogueLine(line: "That felt so...", person: .mc, expression: 1),
        DialogueLine(line: "I used to think that music was just playing notes and making stuff sound good.", person: .mc, expression: 2),
        DialogueLine(line: "But it feels like so much more!", person: .mc, expression: 2),
        DialogueLine(line: "It's like... it's like we're all connected somehow, you know?", person: .mc, expression: 2),
        DialogueLine(line: "Like we're a part of something special!", person: .mc, expression: 2),

        
        DialogueLine(line: "I know what you mean.", person: .brother, expression: 1),
        DialogueLine(line: "It's about finding your place in the world...", person: .brother, expression: 1),
        DialogueLine(line: "And being a part of something bigger than yourself.", person: .brother, expression: 1),

        
        DialogueLine(line: "Exactly! And today —", person: .mc, expression: 2),
        DialogueLine(line: "Today I felt like I truly understood that for the first time.", person: .mc, expression: 1),
        
        OtherAction(autoAdvance: false, action: "end"),
    ]

    
    init() {
    }
    
    func advance(stayAtLine: Bool = false, skipLine: Bool = false) {
        
        if onAutoAdvance {
            return
        }
        
        if rollbackNext {
            self.actionLineIndex -= 1
            rollbackNext = false
        }
        
        self.timer = nil
        
        
        if skipLine {
            self.actionLineIndex += 1
        }
        
        self.actionLineIndex += 1
        
        print(self.actionLineIndex)
        
        
        if let currentAction = self.actions[self.actionLineIndex] as? ChangeBackground {
            backgroundImage = currentAction.newBackground
        }
        else if let currentAction = self.actions[self.actionLineIndex] as? DialogueLine {
            self.dialogueLine = currentAction.line
            if currentAction.person == .mc {
                self.isDialogueAtLeft = true
                dialogueCharacterImage = "girl" + String(currentAction.expression)
            }
            else {
                self.isDialogueAtLeft = false
                dialogueCharacterImage = "brother" + String(currentAction.expression)
            }
        }
        else if let currentAction = self.actions[self.actionLineIndex] as? OtherAction {
            
            switch currentAction.action {
            case "lower_dire":
                direOffset = 1000
            case "start_rehearsal_music":
                rhythm.start_music(0, loop: true)
            case "highlight_tambourine":
                tambourineOffset = -100
                tambourineShake = 20
                self.advance()
                _ = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: false) { _ in
                    self.tambourineShake = -20
                    _ = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: false) { _ in
                        self.tambourineShake = 20
                        _ = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: false) { _ in
                            self.tambourineShake = -20
                            _ = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: false) { _ in
                                self.tambourineShake = 0

                            }
                        }
                    }
                    
                }
                return
                
            case "show_tambourine":
                tambourineOffset = 1000
                _ = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { _ in
                    self.showGame = true
//                    self.rhythm.isCheckingShakes = true
                }
                
            case "start_tambourine":
                advanceLocked = true
                self.rhythm.isCheckingShakes = true
                self.advance()
                return
                
            case "stage_2_dialogue":
                advanceLocked = false
                self.rhythm.isCheckingShakes = false
                
                self.advance()
                return
                
                
            case "start_tambourine2":
                advanceLocked = true
                self.rhythm.start_music(1)
                self.rhythm.isCheckingShakes = true
                self.advance()
                return
                
                
            case "stage_3_dialogue":
                advanceLocked = false
                self.rhythm.isCheckingShakes = false
                self.advance()
                return
            
            case "start_tambourine3":
                advanceLocked = true
                self.rhythm.isCheckingShakes = true
                self.rhythm.start_music(2)
                self.advance()
                return
                
            case "final_dialogue":
                advanceLocked = false
                self.rhythm.isCheckingShakes = false
                self.shadowOpacity = 0.3
                self.advance()
                return
                
            case "end":
                advanceLocked = true
                self.gameColorOpacity = 1.0
                showGame = false
                _ = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: false) { _ in
                    self.gameState = .end
                }
                
                
                
            default:
                break
            }
            
        }
        
        if stayAtLine {
            rollbackNext = true
        }
        
        if self.actions[self.actionLineIndex].autoAdvance {
            self.onAutoAdvance = true
            self.timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { _ in
                print("autoadvanced")
                self.onAutoAdvance = false
                self.advance()
            }

        }
        
        
        
        

        
    }
    
}
