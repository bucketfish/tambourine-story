//
//  File.swift
//  
//
//  Created by Tongyu Jiang on 17/2/24.
//

import Foundation

protocol Action {
    var autoAdvance: Bool { get set }
    var staySame: Bool { get set }
}

struct DialogueLine: Action {
    var autoAdvance: Bool = false
    var staySame: Bool = false
    let line: String
    let person: Character
    var expression: Int = 0
    
    enum Character: String {
        case mc
        case brother
    }
}

struct ChangeBackground: Action {
    var autoAdvance: Bool = true
    var staySame: Bool = false
    let newBackground: String
}

struct OtherAction: Action {
    var autoAdvance: Bool = false
    var staySame: Bool = false
    let action: String
}
