//
//  SwiftUIView.swift
//  
//
//  Created by Tongyu Jiang on 14/2/24.
//

import SwiftUI

struct DialogueView: View {
    @Binding var imageName: String
    @Binding var dialogueLine: String
    @Binding var speakingIsLeft: Bool
    
    @State var time: Double = 0.05
    
    @State var text_to_show: String = "(Tap to continue)"
    @State var text_offset: Int = 0
    
    @State var is_bold: Bool = false
    @State var align = TextAlignment.center

    
    @State var upperBound = String.Index(utf16Offset: 0, in: "text")
    
    @Binding var dialogueLoading: Bool
    @Binding var dialogueOnFast: Bool
    
    

    var body: some View {
        VStack {
            
            if #available(iOS 17.0, *) {
                Spacer()
                .onChange(of: dialogueLine) { old, new in
                    
                    text_to_show = ""
                    text_offset = 0
                    dialogueLoading = true
                    dialogueOnFast = false
                    
                    advanceText()
                }
            }
            else {
                Spacer()
                .onChange(of: dialogueLine) { new in
                    
                    text_to_show = ""
                    text_offset = 0
                    dialogueLoading = true
                    dialogueOnFast = false
                    
                    advanceText()
                }
            }
            
            
            
            HStack {
                if speakingIsLeft {
                    Image(imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                }
                else {
                    Spacer()
                }
                
                if dialogueLine != "" {
                    ChatBubble(isLeft: speakingIsLeft) {
                        Text(text_to_show)
                            
                    }
                }
                    
                
                
                if !speakingIsLeft {
                    Image(imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                }
                else {
                    Spacer()
                }
                
                
            }
            .onAppear {
                
                text_to_show = ""
                text_offset = 0
                dialogueLoading = true
                dialogueOnFast = false
                
                advanceText()
            }
            .padding(60)
        }
        
    }
    
    func advanceText() {
//        _ = Timer.scheduledTimer(withTimeInterval: time, repeats: true) { timer in
            
            if text_offset < dialogueLine.count {
                text_offset += 1
                
                upperBound = dialogueLine.index(dialogueLine.startIndex, offsetBy: text_offset)
                
                text_to_show = String(dialogueLine[..<upperBound])
                
                _ = Timer.scheduledTimer(withTimeInterval: dialogueOnFast ? time / 5 : time, repeats: false) { timer in
                    advanceText()
                }

            }
            else {
                dialogueLoading = false
            }
        }
}

//#Preview {
//    DialogueView(imageName: .constant("girl1"), dialogueLine: .constant("test"), speakingIsLeft: .constant(true), dialogueLoading: .constant(false), dialogueOnFast: .constant(false))
//}


struct ChatBubble<Content>: View where Content: View {
    var isLeft: Bool
    var content: (() -> Content)
    
    init(isLeft: Bool, @ViewBuilder content: @escaping () -> Content) {
        self.content = content
        self.isLeft = isLeft
    }
    
    var body: some View {
        HStack {
            content()
                .font(.title2)
                .foregroundColor(.black)
                .fixedSize(horizontal: false, vertical: true)
                .padding([.leading], isLeft ? 20 : 15)
                .padding([.top, .bottom], 15)
                .padding(.trailing, isLeft ? 15 : 20)
                .background(isLeft
                            ? Color(red: 1, green: 0.73, blue: 0.95)
                            : Color(red: 0.67, green: 0.88, blue: 0.7))
                .clipShape(ChatBubbleShape(isLeft: isLeft))
            
                
        }
    }
}


struct ChatBubbleShape: Shape {
    var isLeft: Bool
    
    func path(in rect: CGRect) -> Path {
        let width = rect.width
        let height = rect.height
        
        var path: Path
        if isLeft {
            path = Path { p in
                p.move(to: CGPoint(x: 25, y: height))
                p.addLine(to: CGPoint(x: width - 20, y: height))
                p.addCurve(to: CGPoint(x: width, y: height - 20),
                           control1: CGPoint(x: width - 8, y: height),
                           control2: CGPoint(x: width, y: height - 8))
                p.addLine(to: CGPoint(x: width, y: 20))
                p.addCurve(to: CGPoint(x: width - 20, y: 0),
                           control1: CGPoint(x: width, y: 8),
                           control2: CGPoint(x: width - 8, y: 0))
                p.addLine(to: CGPoint(x: 21, y: 0))
                p.addCurve(to: CGPoint(x: 4, y: 20),
                           control1: CGPoint(x: 12, y: 0),
                           control2: CGPoint(x: 4, y: 8))
                p.addLine(to: CGPoint(x: 4, y: height - 11))
                p.addCurve(to: CGPoint(x: 0, y: height),
                           control1: CGPoint(x: 4, y: height - 1),
                           control2: CGPoint(x: 0, y: height))
                p.addLine(to: CGPoint(x: -0.05, y: height - 0.01))
                p.addCurve(to: CGPoint(x: 11.0, y: height - 4.0),
                           control1: CGPoint(x: 4.0, y: height + 0.5),
                           control2: CGPoint(x: 8, y: height - 1))
                p.addCurve(to: CGPoint(x: 25, y: height),
                           control1: CGPoint(x: 16, y: height),
                           control2: CGPoint(x: 20, y: height))
                
            }
        }
        else {
            path = Path { p in
                p.move(to: CGPoint(x: width - 25, y: height))
                p.addLine(to: CGPoint(x: 20, y: height))
                p.addCurve(to: CGPoint(x: 0, y: height - 20),
                           control1: CGPoint(x: 8, y: height),
                           control2: CGPoint(x: 0, y: height - 8))
                p.addLine(to: CGPoint(x: 0, y: 20))
                p.addCurve(to: CGPoint(x: 20, y: 0),
                           control1: CGPoint(x: 0, y: 8),
                           control2: CGPoint(x: 8, y: 0))
                p.addLine(to: CGPoint(x: width - 21, y: 0))
                p.addCurve(to: CGPoint(x: width - 4, y: 20),
                           control1: CGPoint(x: width - 12, y: 0),
                           control2: CGPoint(x: width - 4, y: 8))
                p.addLine(to: CGPoint(x: width - 4, y: height - 11))
                p.addCurve(to: CGPoint(x: width, y: height),
                           control1: CGPoint(x: width - 4, y: height - 1),
                           control2: CGPoint(x: width - 0, y: height))
                p.addLine(to: CGPoint(x: width + 0.05, y: height - 0.01))
                p.addCurve(to: CGPoint(x: width - 11.0, y: height - 4.0),
                           control1: CGPoint(x: width - 4.0, y: height + 0.5),
                           control2: CGPoint(x: width - 8, y: height - 1))
                p.addCurve(to: CGPoint(x: width - 25, y: height),
                           control1: CGPoint(x: width - 16, y: height),
                           control2: CGPoint(x: width - 20, y: height))
            }
        }
        
        return path
    }
}

