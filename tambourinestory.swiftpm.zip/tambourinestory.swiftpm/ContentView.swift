import SwiftUI

struct ContentView: View {
    @StateObject var rhythm = RhythmManager.shared
    @StateObject var narrative = NarrativeManager.shared
    
    var body: some View {

        if narrative.gameState == .start {
            StartView()
                .environmentObject(rhythm)
                .environmentObject(narrative)
        }
        else if narrative.gameState == .game {
            CutscenePanView()
                .environmentObject(rhythm)
                .environmentObject(narrative)
        }
        else {
            EndView()
                .environmentObject(rhythm)
        }
    }
    
}

enum GameState {
    case start, game, end
}

#Preview {
    ContentView()
}
