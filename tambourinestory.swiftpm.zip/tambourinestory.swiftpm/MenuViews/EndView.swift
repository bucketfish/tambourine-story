//
//  SwiftUIView.swift
//
//
//  Created by Tongyu Jiang on 18/2/24.
//

import SwiftUI

struct EndView: View {
    @EnvironmentObject var rhythm: RhythmManager
    
    @State var colorOpacity: Double = 1
    
    var body: some View {
        ZStack {
            GeometryReader { proxy in
                ZStack {
                    Image("end")
                        .resizable()
                        .scaledToFill()

                }
                    .frame(height: proxy.size.height * 1.15)
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .offset(
                        x: clamp(rhythm.motionPitch * 60 + rhythm.motionYaw * 60, -150, 150),
                        y: clamp(-50 - rhythm.motionRoll * 75, -25, 25)
                        )
            }
            
            Color(red: 0.6, green: 0.74, blue: 1)
                .ignoresSafeArea(.all)
                .opacity(colorOpacity)
                .animation(.spring(blendDuration: 0.4), value: colorOpacity)
            
//            Color(.black)
//                .opacity(narrative.shadowOpacity)
//                .animation(.spring(), value: narrative.shadowOpacity)
//
//
////            if narrative.showGame {
//            TambourineView(showStuff: $narrative.showGame)
//                .environmentObject(rhythm)
////            }
            
//            DialogueView(imageName: $narrative.dialogueCharacterImage, dialogueLine: $narrative.dialogueLine, speakingIsLeft: $narrative.isDialogueAtLeft, dialogueLoading: $dialogueLoading, dialogueOnFast: $dialogueOnFast)
            
        }
        .onAppear {
            colorOpacity = 0
        }
        
    }
    
    func clamp(_ x: Double, _ from: Double, _ to: Double) -> Double {
        if (x < from) {
            return from
        }
        else if (x > to) {
            return to
        }
        else { return x }
    }
}

//#Preview {
//    StartView()
//}
