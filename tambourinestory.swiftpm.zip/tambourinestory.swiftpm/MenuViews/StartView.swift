//
//  SwiftUIView.swift
//  
//
//  Created by Tongyu Jiang on 18/2/24.
//

import SwiftUI

struct StartView: View {
    @EnvironmentObject var rhythm: RhythmManager
    @EnvironmentObject var narrative: NarrativeManager

    @State var imageNum = 1
    @State var clickLock = false
    @State var colorOpacity: Double = 0
    
//    @Binding var gameState: GameState
    
    
    
    var body: some View {
        ZStack {
            GeometryReader { proxy in
                ZStack {
                    Image("start\(imageNum)")
                        .resizable()
                        .scaledToFill()

//                    Image("tambourine_in_room")
//                        .resizable()
//                        .scaledToFill()
//                        .rotationEffect(.degrees(Double(narrative.tambourineShake)), anchor: UnitPoint(x: 0.4, y: 0.68))
//                        .offset(y: CGFloat(narrative.tambourineOffset))
//                        .animation(.spring(), value: narrative.tambourineOffset)
//                        .animation(.spring(), value: narrative.tambourineShake)

                }
                    .frame(height: proxy.size.height * 1.15)
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .offset(
                        x: clamp(rhythm.motionPitch * 60 + rhythm.motionYaw * 60, -150, 150),
                        y: clamp(-50 - rhythm.motionRoll * 75, -25, 25)
                        )
            }
            
            Color(red: 0.6, green: 0.74, blue: 1)
                .ignoresSafeArea(.all)
                .opacity(colorOpacity)
                .animation(.spring(blendDuration: 0.4), value: colorOpacity)
            
//            Color(.black)
//                .opacity(narrative.shadowOpacity)
//                .animation(.spring(), value: narrative.shadowOpacity)
//            
//            
////            if narrative.showGame {
//            TambourineView(showStuff: $narrative.showGame)
//                .environmentObject(rhythm)
////            }
            
//            DialogueView(imageName: $narrative.dialogueCharacterImage, dialogueLine: $narrative.dialogueLine, speakingIsLeft: $narrative.isDialogueAtLeft, dialogueLoading: $dialogueLoading, dialogueOnFast: $dialogueOnFast)
            
        }
        .onTapGesture(count: 1) {
            if clickLock {
                
            }
            else if imageNum == 1 {
                
                clickLock = true
                colorOpacity = 1
                
                _ = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: false) { _ in
                    imageNum += 1
                    colorOpacity = 0
                    
                    _ = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: false) { _ in
                        clickLock = false
                    }
                }
                
            }
            else {
                clickLock = true
                colorOpacity = 1
                _ = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: false) { _ in
                    narrative.gameState = .game
                }
            }
        }
    }
    
    func clamp(_ x: Double, _ from: Double, _ to: Double) -> Double {
        if (x < from) {
            return from
        }
        else if (x > to) {
            return to
        }
        else { return x }
    }
}

//#Preview {
//    StartView()
//}
