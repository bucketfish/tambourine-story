//
//  SwiftUIView.swift
//  
//
//  Created by Tongyu Jiang on 3/2/24.
//

import SwiftUI
import CoreMotion

struct TambourineView: View {
    @EnvironmentObject var rhythm: RhythmManager

    @Binding var showStuff: Bool
    var motionManager = CMMotionManager()
    
    

    var body: some View {
        HStack {
            ZStack {
//                Color(!rhythm.isSounding ? .clear:
//                        rhythm.currentNoteIsCorrect ? .green : .red)
                
                
                
                VStack{
//                    Text("debug: \(rhythm.currentNoteIsCorrect ? "yes" : "no") lol \(rhythm.currentBarNumber) lol \(rhythm.currentNoteNumberOfBar ?? -1)")
                    if showStuff {
                        
                        JumpView()
                            .environmentObject(rhythm)
                            .frame(height: 200)
                        
                        
                        TambourineRhythmView()
                            .environmentObject(rhythm)
                        
                        TambourineModelView()
                            .environmentObject(rhythm)
                    }
                    
                }
            }
        }
        .ignoresSafeArea(.all)
//        .onAppear {
//            rhythm.start_music()
//        }
    }
}

//#Preview {
//    TambourineView()
//}
