import SwiftUI
import SceneKit
import CoreMotion


struct SceneKitView: UIViewRepresentable {
    @Binding var pitch: Double
    @Binding var yaw: Double
    @Binding var roll: Double

    func makeUIView(context: UIViewRepresentableContext<SceneKitView>) -> SCNView {
        let sceneView = SCNView()

        guard let tambourine = SCNScene(named: "tambourine.scn") else {
            fatalError("Could not find scene")
        }

        sceneView.scene = tambourine
        let entire_tambourine = sceneView.scene?.rootNode.childNode(withName: "tambourine", recursively: true)
        
        entire_tambourine?.scale = SCNVector3(x: 1.5, y: 1.5, z: 1.5)
        
        

        sceneView.allowsCameraControl = false
        sceneView.autoenablesDefaultLighting = true
        sceneView.defaultCameraController.maximumVerticalAngle = 0.001

        sceneView.backgroundColor = .clear

        return sceneView
    }
    
    func updateUIView(_ uiView: SCNView, context: UIViewRepresentableContext<SceneKitView>) {
        
        let rotate = SCNAction.rotateTo(x: -self.roll, y: self.pitch, z: self.yaw, duration: 0.1)
        
        uiView.scene?.rootNode.childNode(withName: "tambourine", recursively: false)?.runAction(rotate)
        
    }
    
    typealias UIViewType = SCNView
}

struct TambourineModelView: View {
    @EnvironmentObject var rhythm: RhythmManager
    
    var body: some View {
        SceneKitView(pitch: $rhythm.motionPitch, yaw: $rhythm.motionYaw, roll: $rhythm.motionRoll)
    }
}

#Preview {
    TambourineModelView()
        .environmentObject(RhythmManager())
}

