//
//  SwiftUIView.swift
//  
//
//  Created by Tongyu Jiang on 13/2/24.
//

import SwiftUI

struct JumpView: View {
    @State var jumpFrame = 0
    @EnvironmentObject var rhythm: RhythmManager

    @State var timer: Timer?

    @State var size: CGSize = CGSize()
    
    var body: some View {
        ZStack {
                Image("jump\(rhythm.jumpFrame)")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .offset(x: rhythm.jumpOffset - 455, y: 10)
            }
    }
}

#Preview {
    JumpView()
}
