//
//  SwiftUIView.swift
//
//
//  Created by Tongyu Jiang on 3/2/24.
//

import SwiftUI

struct TambourineRhythmView: View {
    @EnvironmentObject var rhythm: RhythmManager
    
    @State var circleSize = 80
    
    var body: some View {
        
            HStack (spacing: 50){
                ForEach(0..<8) { beatnum in
                    ZStack {
                        RoundedRectangle(cornerRadius: 5)
                            .foregroundColor(.black)
                            .frame(width: (beatnum == 0 || beatnum == 4) ? 6 : 3, height: CGFloat(circleSize) + ((beatnum == 0 || beatnum == 4) ? 24 : 0))
                            .frame(width: CGFloat(circleSize), height: CGFloat(circleSize))
                        
                        
                        
                        if rhythm.isCheckingShakes {

                            if Double(Double(rhythm.currentTime.truncatingRemainder(dividingBy:Double(rhythm.timePerBar))) - 0.6) >= Double(Double(beatnum) / 4.0) {
                                
                                if rhythm.realCurrentBarNumber + 1 < rhythm.beatSequences.count {
                                    if (rhythm.beatSequences[rhythm.realCurrentBarNumber + 1].contains(Double(beatnum))) {
                                        Image("tobeat")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: CGFloat(circleSize), height: CGFloat(circleSize))
                                            .opacity(1)
                                    }
                                    
                                    else {
                                        Circle().fill(.clear)
                                            .frame(width: CGFloat(circleSize), height: CGFloat(circleSize))
                                    }
                                }
                                
                            }
                            else {
                                
                                if (rhythm.beatSequences[rhythm.realCurrentBarNumber].contains(Double(beatnum))) {
                                    ZStack {
                                        RhythmBeatCircleView(beatNum: Double(beatnum), time: $rhythm.currentTime)
                                            .environmentObject(rhythm)
                                            .frame(width: CGFloat(circleSize), height: CGFloat(circleSize))
                                        
                                        
                                        if let beatIndexNum = rhythm.beatSequences[rhythm.realCurrentBarNumber].firstIndex(of: Double(beatnum)) {
                                            // if
                                            if rhythm.hitsOfCurrentBar.count > beatIndexNum {
                                                Image(rhythm.hitsOfCurrentBar[beatIndexNum] ? "hit" : "miss")
                                                    .resizable()
                                                    .scaledToFit()
                                                    .frame(width: CGFloat(circleSize), height: CGFloat(circleSize))
                                                    .opacity(Double(Double(rhythm.currentTime.truncatingRemainder(dividingBy:Double(rhythm.timePerBar))) - 0.6) >= Double(Double(beatnum) / 4.0) ? 0 : 1)
                                            }
                                            
                                        }
                                    }
                                    
                                }
                                else {
                                    Circle().fill(.clear)
                                        .frame(width: CGFloat(circleSize), height: CGFloat(circleSize))
                                }
                            }
                        }
                    }
                    
                }
            }
            .padding(.horizontal, 50)


    }
}

struct RhythmBeatCircleView: View {
    @EnvironmentObject var rhythm: RhythmManager
    //    let beatsPerBar =
    @State var beatNum: Double = 2
    @Binding var time: Double
    var body: some View {
        Image(
            (time.truncatingRemainder(dividingBy:Double(rhythm.timePerBar)) > (beatNum / 4) &&
             time.truncatingRemainder(dividingBy:Double(rhythm.timePerBar)) < (beatNum / 4) + 0.2)
            ? "curbeat" : "tobeat")
        .resizable()
        .scaledToFit()
        .offset(y: time.truncatingRemainder(dividingBy:Double(rhythm.timePerBar)) > (beatNum / 4) &&
                time.truncatingRemainder(dividingBy:Double(rhythm.timePerBar)) < (beatNum / 4) + 0.2 && rhythm.currentNoteIsCorrect ? 20 : 0 )
        .opacity(Double(Double(rhythm.currentTime.truncatingRemainder(dividingBy:Double(rhythm.timePerBar))) - 0.2) >= Double(Double(beatNum) / 4.0) ? 0.5 : 1)
    }
}
