//
//  SoundHandler.swift
//  colorsong
//
//  Created by Tongyu Jiang on 3/2/24.
//


// this is actually used btw

import Foundation
import AVFoundation

class CustomSoundPlayer: ObservableObject {
    static let shared = CustomSoundPlayer()

    var player:AVAudioPlayer?
    var soundPath: URL? = nil
//    var volume: Float = 0.5


    init(player: AVAudioPlayer? = nil, soundPath: URL? = nil) {
        self.player = player
        self.soundPath = soundPath

        if let bundlePath = Bundle.main.path(forResource: "um3.mp3", ofType:nil) {
            self.soundPath = URL(fileURLWithPath: bundlePath)
            self.player = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: bundlePath), fileTypeHint: AVFileType.mp3.rawValue)
            //                player?.volume = self.volume
            self.player?.volume = 1.0

        }
    }
    

    func play(_ path: String = "") {
        player?.stop()
        player?.prepareToPlay()
        
        self.player?.volume = 1.0
        
        if path != "" {
            if let bundlePath = Bundle.main.path(forResource: "\(path).mp3", ofType:nil) {
                self.soundPath = URL(fileURLWithPath: bundlePath)
                self.player = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: bundlePath), fileTypeHint: AVFileType.mp3.rawValue)
                
                self.player?.volume = 1.0
                
            }
        }
        
        if self.soundPath != nil {
            player?.currentTime = 0
            self.player?.volume = 1.0
            
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback)
            } catch(let error) {
                print(error.localizedDescription)
            }
            
            player?.play()
        }
    }
    
    func changeSoundPath(to path: String) {
        if let bundlePath = Bundle.main.path(forResource: "\(path).mp3", ofType:nil) {
            self.soundPath = URL(fileURLWithPath: bundlePath)
            self.player = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: bundlePath), fileTypeHint: AVFileType.mp3.rawValue)
            
            self.player?.volume = 1.0
            
        }

    }
    
    
    func stopAllSounds() {
        player?.stop()
    }
    
    
}

